CREATE TRIGGER updateDate
BEFORE UPDATE ON p_patroltype
FOR EACH ROW
  begin

set new.Modify_Date = now();

end;
