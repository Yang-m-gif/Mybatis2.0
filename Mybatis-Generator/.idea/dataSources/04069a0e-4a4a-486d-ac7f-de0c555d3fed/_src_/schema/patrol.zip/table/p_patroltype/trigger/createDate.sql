CREATE TRIGGER createDate
BEFORE INSERT ON p_patroltype
FOR EACH ROW
  begin

Set new.Modify_Date = now();

end;
